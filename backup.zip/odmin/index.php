<?php 
header("Location: http://uranius.pp.ua/");
//include dirname(__FILE__).'/site/index.php';
?>\
