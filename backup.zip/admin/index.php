<?php
session_start();
if(isset($_GET['logout'])){
session_destroy();
header('Location: index.php');
exit();
}

if(!isset($_SESSION['authorized'])){

if(isset($_POST['submit'])){
if($_POST['username'] =='virus' && $_POST['password'] == 'knopkauliana3101' || $_POST['username'] =='da411d' && $_POST['password'] == 'qwerty27'){
$_SESSION['authorized'] = true;
header('Location: index.php');
exit();
}
}

?>

<form action='' method='post' autocomplete='off'>
<p>Username: <input type="text" name="username" value=""></p>
<p>Password: <input type="password" name="password" value=""></p>
<p><input type="submit" name="submit" value="Login"></p>
</form>

<?php } else { ?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Admin</title>

		<!-- jQuery and jQuery UI (REQUIRED) -->
		<link rel="stylesheet" type="text/css" media="screen" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/themes/smoothness/jquery-ui.css">
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>

		<!-- elFinder CSS (REQUIRED) -->
		<link rel="stylesheet" type="text/css" media="screen" href="css/elfinder.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/theme.css">

		<!-- elFinder JS (REQUIRED) -->
		<script type="text/javascript" src="js/elfinder.min.js"></script>

		<!-- elFinder translation (OPTIONAL) -->
		<script type="text/javascript" src="js/i18n/elfinder.ru.js"></script>
		<script type="text/javascript" src="js/i18n/elfinder.uk.js"></script>
	<!-- elFinder initialization (REQUIRED) -->
<script type="text/javascript" charset="utf-8">
$().ready(function() {
var elf = $('#elfinder').elfinder({
url : 'php/connector.php', // connector URL (REQUIRED)
lang : 'ru',
height : '800'
}).elfinder('instance');
});
</script>
	</head>
	<body>

		<!-- Element where elFinder will be created (REQUIRED) -->
		<div id="elfinder"></div>
<p><a href='?logout'>Logout</a></p>
	</body>
</html>
<?php } ?>
